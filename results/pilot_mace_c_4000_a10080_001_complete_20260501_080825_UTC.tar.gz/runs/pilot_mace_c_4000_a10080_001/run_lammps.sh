#!/usr/bin/env bash
set -euo pipefail

source /opt/venv/bin/activate || true
if [ -f /workspace/cuzr_mddms_runtime.env ]; then
  source /workspace/cuzr_mddms_runtime.env
fi

LMP_CMD='lmp -k on g 1 -sf kk -pk kokkos newton on neigh half'

run_stage() {
  local input="$1"
  local log="${input%.in}.log"
  echo "[run] $input -> $log"
  ${LMP_CMD} -log "$log" -in "$input"
}

run_stage 00_prepare_melt_quench.in
run_stage 01_relax_npt.in
run_stage 02_equilibrate_nvt.in
run_stage 03_mddms_shear.in
